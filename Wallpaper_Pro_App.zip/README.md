# Wallpaper Pro

A responsive wallpaper discovery website built with HTML, CSS, JavaScript and Node.js.

## Run locally
1. Install Node.js 18 or newer.
2. Run `npm install`
3. Run `npm start`
4. Open `http://localhost:3000`

## Deploy on Render
- Create a **Web Service** and connect this GitHub repository.
- Runtime: Node
- Build Command: `npm install`
- Start Command: `npm start`
- Deploy.

## Included
- Responsive premium dark UI
- Wallpaper collections and category filters
- Search
- Full-screen preview
- Download and share
- Favorites saved in the browser
- Trending (4K) view
- No admin panel (as requested)

## Add your own wallpapers
Edit the `wallpapers` array in `public/index.html`. Each item uses:
`{ id, title, cat, quality, url }`

The sample image URLs are remote Unsplash images, so an internet connection is required to load them. This project does not include an admin upload system or cloud storage.
